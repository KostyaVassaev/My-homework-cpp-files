﻿#include <iostream>

int main()
{

}