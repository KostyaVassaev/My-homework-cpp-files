#pragma once
#include <vector>

std::vector<int> increaseVecElements(const std::vector<int>& vec, int n);